using INVENTORYAPP.Data;
using INVENTORYAPP.Features.Masters.Accounts.DTOs;
using INVENTORYAPP.Features.Masters.Parties.DTOs;
using INVENTORYAPP.Features.Payments.DTOs;
using INVENTORYAPP.Features.Payments.Interface;
using INVENTORYAPP.Models;
using Microsoft.EntityFrameworkCore;

namespace INVENTORYAPP.Features.Payments.Repositories;

public class PaymentRepository : IPaymentRepository
{
    private readonly AppDbContext _context;

    public PaymentRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<PartyLookupResponse>> GetPartiesAsync()
    {
        return await _context.Parties
            .Where(x => x.IsActive && !x.IsDeleted)
            .OrderBy(x => x.PartyName)
            .Select(x => new PartyLookupResponse
            {
                Id = x.Id,
                PartyCode = x.PartyCode,
                PartyName = x.PartyName
            })
            .ToListAsync();
    }

    public async Task<List<AccountLookupResponse>> GetAccountsAsync()
    {
        return await _context.Accounts
            .Where(x => x.IsActive && !x.IsDeleted)
            .OrderBy(x => x.AccountName)
            .Select(x => new AccountLookupResponse
            {
                Id = x.Id,
                AccountCode = x.AccountCode,
                AccountName = x.AccountName
            })
            .ToListAsync();
    }

    public async Task<long> SavePaymentAsync(SavePaymentDto dto)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();

        try
        {
            var party = await _context.Parties
                .FirstOrDefaultAsync(x =>
                    x.Id == dto.PartyId &&
                    x.IsActive &&
                    !x.IsDeleted);

            if (party == null)
                throw new Exception($"Party not found. PartyId = {dto.PartyId}");

            PaymentEntry? payment = await _context.PaymentEntries
                .FirstOrDefaultAsync(x => x.DocNo == dto.DocNo);

            if (payment != null)
            {
                payment.DocDate = dto.DocDate;
                payment.PartyId = dto.PartyId;
                payment.STimestamp = DateTime.Now;
                payment.ModifiedOn = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                var oldDetails = await _context.PaymentEntryDetails
                    .Where(x => x.DocNo == payment.DocNo)
                    .ToListAsync();

                _context.PaymentEntryDetails.RemoveRange(oldDetails);
                await _context.SaveChangesAsync();
            }
            else
            {
                payment = new PaymentEntry
                {
                    DocDate = dto.DocDate,
                    PartyId = dto.PartyId,
                    STimestamp = DateTime.Now
                };

                _context.PaymentEntries.Add(payment);
                await _context.SaveChangesAsync();
            }

            int slNo = 1;

            foreach (var item in dto.Details)
            {
                var account = await _context.Accounts
                    .FirstOrDefaultAsync(x =>
                        x.Id == item.AccountId &&
                        x.IsActive &&
                        !x.IsDeleted);

                if (account == null)
                    throw new Exception($"Account not found. AccountId = {item.AccountId}");

                var detail = new PaymentEntryDetail
                {
                    DocNo = payment.DocNo,
                    DocDate = dto.DocDate,
                    PartyId = dto.PartyId,
                    STimestamp = DateTime.Now,
                    SlNo = slNo++,
                    AccountId = item.AccountId,
                    AcName = account.AccountName,
                    Amount = item.Amount
                };

                _context.PaymentEntryDetails.Add(detail);
            }

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            return payment.DocNo;
        }
        catch
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    public async Task<long> GetNextPaymentNumberAsync()
    {
        var lastDocNo = await _context.PaymentEntries
            .OrderByDescending(x => x.DocNo)
            .Select(x => (long?)x.DocNo)
            .FirstOrDefaultAsync();

        return (lastDocNo ?? 0) + 1;
    }

    public async Task<List<PaymentSearchDto>> SearchAsync(string keyword)
    {
        keyword = keyword?.Trim().ToLower() ?? string.Empty;

        return await (
            from payment in _context.PaymentEntries
            join party in _context.Parties
                on payment.PartyId equals party.Id
            where
                payment.DocNo.ToString().Contains(keyword)
                || party.PartyCode.ToLower().Contains(keyword)
                || party.PartyName.ToLower().Contains(keyword)
                || payment.DocDate.ToString().Contains(keyword)
            select new PaymentSearchDto
            {
                DocNo = payment.DocNo,
                DocDate = payment.DocDate,
                PartyCode = party.PartyCode,
                PartyName = party.PartyName
            })
            .Distinct()
            .OrderByDescending(x => x.DocNo)
            .ToListAsync();
    }

    public async Task<PaymentDto?> GetPaymentByDocNoAsync(long docNo)
    {
        var payment = await _context.PaymentEntries
            .FirstOrDefaultAsync(x => x.DocNo == docNo);

        if (payment == null)
            return null;

        var details = await _context.PaymentEntryDetails
            .Where(x => x.DocNo == docNo)
            .OrderBy(x => x.SlNo)
            .Select(x => new PaymentDetailDto
            {
                AccountId = x.AccountId,
                Amount = x.Amount
            })
            .ToListAsync();

        return new PaymentDto
        {
            DocNo = payment.DocNo,
            DocDate = payment.DocDate,
            PartyId = payment.PartyId,
            Details = details
        };
    }

    public async Task DeletePaymentAsync(long docNo)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();

        try
        {
            var payment = await _context.PaymentEntries
                .FirstOrDefaultAsync(x => x.DocNo == docNo);

            if (payment == null)
                throw new Exception("Payment not found.");

            _context.PaymentEntries.Remove(payment);

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();
        }
        catch
        {
            await transaction.RollbackAsync();
            throw;
        }
    }
}
