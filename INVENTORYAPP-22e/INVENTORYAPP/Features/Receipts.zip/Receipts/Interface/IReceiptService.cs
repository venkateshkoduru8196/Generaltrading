﻿using INVENTORYAPP.Features.Receipts.DTOs;
using INVENTORYAPP.Features.Receipts.Models;
using INVENTORYAPP.Features.Masters.Accounts.DTOs;
using INVENTORYAPP.Features.Masters.Parties.DTOs;


namespace INVENTORYAPP.Features.Receipts.Interface;

public interface IReceiptService
{
    Task<List<PartyLookupResponse>> GetPartiesAsync();

    Task<List<AccountLookupResponse>> GetAccountsAsync();
    Task<long> GetNextReceiptNumberAsync();

    Task<ReceiptResponseDto> SaveReceiptAsync(SaveReceiptDto dto);

    // NEW
    Task<List<ReceiptSearchDto>> SearchAsync(string keyword);

    Task<ReceiptDto?> GetReceiptByDocNoAsync(long docNo);

    Task DeleteReceiptAsync(long docNo);
}