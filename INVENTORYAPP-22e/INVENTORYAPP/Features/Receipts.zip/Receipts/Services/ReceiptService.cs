﻿using INVENTORYAPP.Features.Masters.Accounts.DTOs;
using INVENTORYAPP.Features.Masters.Parties.DTOs;
using INVENTORYAPP.Features.Receipts.DTOs;
using INVENTORYAPP.Features.Receipts.Interface;

namespace INVENTORYAPP.Features.Receipts.Services;

public class ReceiptService : IReceiptService
{
    private readonly IReceiptRepository _receiptRepository;

    public ReceiptService(
        IReceiptRepository receiptRepository)
    {
        _receiptRepository = receiptRepository;
    }

    //==========================================
    // Get Parties
    //==========================================

    public async Task<List<PartyLookupResponse>> GetPartiesAsync()
    {
        return await _receiptRepository.GetPartiesAsync();
    }

    //==========================================
    // Get Accounts
    //==========================================

    public async Task<List<AccountLookupResponse>> GetAccountsAsync()
    {
        return await _receiptRepository.GetAccountsAsync();
    }

    //==========================================
    // Next Receipt Number
    //==========================================

    public async Task<long> GetNextReceiptNumberAsync()
    {
        return await _receiptRepository.GetNextReceiptNumberAsync();
    }

    //==========================================
    // Save Receipt
    //==========================================

    public async Task<ReceiptResponseDto> SaveReceiptAsync(
        SaveReceiptDto dto)
    {
        var docNo = await _receiptRepository.SaveReceiptAsync(dto);

        return new ReceiptResponseDto
        {
            Success = true,
            Message = "Receipt saved successfully.",
            DocNo = docNo
        };
    }

    //==========================================
    // Search Receipts
    //==========================================

    public async Task<List<ReceiptSearchDto>> SearchAsync(
        string keyword)
    {
        return await _receiptRepository.SearchAsync(keyword);
    }

    //==========================================
    // Get Receipt By DocNo
    //==========================================

    public async Task<ReceiptDto?> GetReceiptByDocNoAsync(
        long docNo)
    {
        return await _receiptRepository.GetReceiptByDocNoAsync(docNo);
    }

    //==========================================
    // Delete Receipt
    //==========================================

    public async Task DeleteReceiptAsync(long docNo)
    {
        await _receiptRepository.DeleteReceiptAsync(docNo);
    }
}