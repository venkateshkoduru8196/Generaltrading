﻿using INVENTORYAPP.Features.Receipts.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace INVENTORYAPP.Features.Receipts.Configurations;

public class PartyMasterConfiguration
    : IEntityTypeConfiguration<PartyMaster>
{
    public void Configure(
        EntityTypeBuilder<PartyMaster> builder)
    {
        builder.ToTable("partymst");

        builder.HasKey(x => x.PartyCode);

        builder.Property(x => x.PartyName)
            .HasMaxLength(100);
    }
}