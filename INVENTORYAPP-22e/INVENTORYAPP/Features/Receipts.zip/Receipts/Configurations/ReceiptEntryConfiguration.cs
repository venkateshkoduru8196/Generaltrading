﻿using INVENTORYAPP.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace INVENTORYAPP.Features.Receipts.Configurations;

public class ReceiptEntryConfiguration
    : IEntityTypeConfiguration<ReceiptEntry>
{
    public void Configure(
        EntityTypeBuilder<ReceiptEntry> builder)
    {
        builder.ToTable("crc");

        // Primary Key
        builder.HasKey(x => x.DocNo);

        builder.Property(x => x.DocNo)
            .ValueGeneratedOnAdd();

        // Receipt
        builder.Property(x => x.DocDate);

        builder.Property(x => x.PartyId);

        builder.Property(x => x.STimestamp);

        // Party Relationship
        builder.HasOne(x => x.Party)
            .WithMany()
            .HasForeignKey(x => x.PartyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}