﻿using INVENTORYAPP.Features.Receipts.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace INVENTORYAPP.Features.Receipts.Configurations;

public class AccountMasterConfiguration : IEntityTypeConfiguration<AccountMaster>
{
    public void Configure(EntityTypeBuilder<AccountMaster> builder)
    {
        builder.ToTable("accmst", "tradinguser");

        builder.HasKey(x => x.AccCode);

        builder.Property(x => x.AccCode)
               .HasColumnName("AccCode");

        builder.Property(x => x.AcName)
               .HasColumnName("AcName")
               .HasMaxLength(200);

        // Ignore this property because it doesn't exist in SQL
        builder.Ignore(x => x.Id);
    }
}