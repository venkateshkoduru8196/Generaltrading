﻿using INVENTORYAPP.Features.Receipts.DTOs;
using INVENTORYAPP.Features.Receipts.Models;
using INVENTORYAPP.Features.Masters.Parties.DTOs;
using INVENTORYAPP.Features.Masters.Accounts.DTOs;
namespace INVENTORYAPP.Features.Receipts.Interface;

public interface IReceiptRepository
{
    Task<List<PartyLookupResponse>> GetPartiesAsync();

    Task<List<AccountLookupResponse>> GetAccountsAsync();


    Task<long> GetNextReceiptNumberAsync();
    Task<List<ReceiptSearchDto>> SearchAsync(string keyword);
    Task<long> SaveReceiptAsync(SaveReceiptDto dto);
    Task<ReceiptDto?> GetReceiptByDocNoAsync(long docNo);
    Task DeleteReceiptAsync(long docNo);
}